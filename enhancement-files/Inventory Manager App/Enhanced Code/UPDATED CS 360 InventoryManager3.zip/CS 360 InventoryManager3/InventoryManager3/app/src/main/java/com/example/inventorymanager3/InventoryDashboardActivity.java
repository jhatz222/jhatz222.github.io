package com.example.inventorymanager;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;    // NEW: import layout manager for RecyclerView
import androidx.recyclerview.widget.RecyclerView;          // NEW: import RecyclerView

import java.util.List;                                     // NEW: import List

public class InventoryDashboardActivity extends AppCompatActivity {
    private DataRepository repo;                           // NEW: field to hold the Room-backed repository

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_dashboard);

        // --- NEW: Initialize the repository singleton backed by Room DB
        repo = DataRepository.getInstance(getApplicationContext());

        // --- NEW: Fetch all stored InventoryItem objects from the database
        List<InventoryItem> allItems = repo.getAllItems();

        // --- NEW: Find the RecyclerView in the layout
        RecyclerView rv = findViewById(R.id.recyclerview);

        // --- NEW: Give it a LayoutManager so items lay out and scroll vertically
        rv.setLayoutManager(new LinearLayoutManager(this));

        // --- NEW: Hook up the adapter, passing in the list from the database
        rv.setAdapter(new InventoryAdapter(allItems));
    }
}

/*
Enhancements Explanation:

Imports: Brings in the RecyclerView, LinearLayoutManager, and List classes needed for the new data display.

DataRepository repo;: Stores a reference to the Room‐based repository.

repo = DataRepository.getInstance(...): Boots up the database and DAO behind the scenes.

List<InventoryItem> allItems = repo.getAllItems();: Pulls every item from the Room database in one fast query.

rv.setLayoutManager(...): Makes sure that the RecyclerView can arrange its children and scroll.

rv.setAdapter(...): Feeds the live list into the UI, replacing any hard-coded or raw-data approach.
 */