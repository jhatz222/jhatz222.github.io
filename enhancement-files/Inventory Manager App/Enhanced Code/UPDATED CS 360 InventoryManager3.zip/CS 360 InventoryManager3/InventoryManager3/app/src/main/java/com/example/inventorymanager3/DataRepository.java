package com.example.inventorymanager;

import android.content.Context;

import androidx.room.Room;

import java.util.List;

public class DataRepository {
    private static DataRepository instance;
    private final ItemDao dao;

    private DataRepository(Context ctx) {
        AppDatabase db = Room.databaseBuilder(
                ctx.getApplicationContext(),
                AppDatabase.class,
                "inventory-db"
        ).build();
        dao = db.itemDao();
    }

    /** 
     * Get the singleton instance of the repository.
     */
    public static synchronized DataRepository getInstance(Context ctx) {
        if (instance == null) {
            instance = new DataRepository(ctx);
        }
        return instance;
    }

    /**
     * Fetch all items from the database.
     */
    public List<Item> getAllItems() {
        return dao.getAll();
    }

    /**
     * Insert a new item into the database.
     */
    public void addItem(Item item) {
        dao.insert(item);
    }

    /**
     * Update an existing item in the database.
     */
    public void updateItem(Item item) {
        dao.update(item);
    }

    /**
     * Delete an item from the database.
     */
    public void deleteItem(Item item) {
        dao.delete(item);
    }

    /**
     * (Optional) Fetch a single item by its ID.
     */
    public Item getItemById(int id) {
        return dao.findById(id);
    }
}
