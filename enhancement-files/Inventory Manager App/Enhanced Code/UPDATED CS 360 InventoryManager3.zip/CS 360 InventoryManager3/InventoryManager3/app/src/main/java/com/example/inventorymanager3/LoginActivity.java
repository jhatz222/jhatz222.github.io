package com.example.inventorymanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;                           // NEW: import Toast for user messages
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private DataRepository repo;                       // NEW: reference to the data repository

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // --- NEW: initialize the repository (connects to Room database)
        repo = DataRepository.getInstance(getApplicationContext());

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // --- NEW: Make sure data is loaded before moving on
                if (!repo.isInitialized()) {
                    Toast.makeText(
                        LoginActivity.this,
                        "Please wait—loading inventory items now!",
                        Toast.LENGTH_SHORT
                    ).show();
                    return;  // skip navigation until repository is ready
                }

                // existing behavior: go to the dashboard once data is ready
                Intent intent = new Intent(LoginActivity.this, InventoryDashboardActivity.class);
                startActivity(intent);
            }
        });
    }
}

/*
Enhancements Explanation:

repo = DataRepository.getInstance(...): Boots up the Room database and DAO.

if (!repo.isInitialized()) { … }: Checks that the database is ready. Shows a short message and prevents moving forward if data isn’t loaded yet.

Toast.makeText(…): Provides feedback to the user to wait while data loads.

Import of Toast and reference to DataRepository: Enables the new checks and messaging.
 */