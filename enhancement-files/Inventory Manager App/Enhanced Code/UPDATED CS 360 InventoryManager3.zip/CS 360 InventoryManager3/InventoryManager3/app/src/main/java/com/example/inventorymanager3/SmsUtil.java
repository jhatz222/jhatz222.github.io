package com.example.inventorymanager;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.example.inventorymanager.data.InventoryItem;    // NEW: import the app’s data model
import com.example.inventorymanager.DataRepository;       // NEW: import the Room-backed repository

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SmsUtil {
    public static PendingIntent getPendingIntent(Context context, Intent intent, int requestCode) {
        return PendingIntent.getActivity(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    // --- NEW: Parse an incoming SMS text into an InventoryItem and save it ---
    public static void handleIncomingSms(Context context, String rawMessage) {
        try {
            // 1. Convert the raw SMS string into an InventoryItem object
            InventoryItem item = parseSms(rawMessage);

            // 2. Insert the new item into the database via Room
            DataRepository repo = DataRepository.getInstance(context);
            repo.insertItem(item);

        } catch (ParseException e) {
            // If date parsing fails, ignore or log the error
            e.printStackTrace();
        }
    }

    // --- NEW: Break a semicolon-separated SMS into fields and build an InventoryItem ---
    public static InventoryItem parseSms(String rawMessage) throws ParseException {
        // Example rawMessage: "Name: Buy supplies; Date: 2025-06-15"
        String[] parts = rawMessage.split(";");
        String namePart = parts[0].split(":", 2)[1].trim();
        String datePart = parts[1].split(":", 2)[1].trim();

        // Convert the date string into a Date object (implement parseDate format)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date dueDate = sdf.parse(datePart);

        // Return a new InventoryItem for insertion
        return new InventoryItem(namePart, dueDate);
    }
}


/*
Enhancements Explanation:
Imports: Brought in InventoryItem and DataRepository so SMS data can be converted and stored.

handleIncomingSms: A new helper that calls parseSms, then inserts the resulting InventoryItem into the Room database.

parseSms: Splits the SMS text on “;”, extracts the name and date fields, parses the date, and returns a populated InventoryItem.

Error handling: Catches ParseException if the date format is wrong, preventing crashes.

These changes let the app automatically turn a formatted SMS into a saved inventory reminder without manual entry.
 */