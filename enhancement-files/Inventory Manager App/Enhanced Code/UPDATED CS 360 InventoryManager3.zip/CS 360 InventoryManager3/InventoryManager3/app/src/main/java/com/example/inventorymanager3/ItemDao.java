@Dao
public interface ItemDao {
    @Query("SELECT * FROM items")
    List<Item> getAll();
    
    @Insert
    void insert(Item item);
    
    @Update
    void update(Item item);
    
    @Delete
    void delete(Item item);
}
