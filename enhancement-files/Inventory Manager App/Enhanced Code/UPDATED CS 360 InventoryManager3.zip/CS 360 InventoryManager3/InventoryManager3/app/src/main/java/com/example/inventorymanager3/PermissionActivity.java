package com.example.inventorymanager;

import android.Manifest;
import android.content.Intent;                    // NEW: import Intent to start next Activity
import android.content.pm.PackageManager;        // NEW: import PackageManager to check permission result
import android.os.Bundle;
import android.widget.Toast;                     // NEW: import Toast for user feedback
import androidx.annotation.NonNull;               // NEW: import NonNull annotation
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class PermissionActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        // Request SMS send permission from the user
        ActivityCompat.requestPermissions(
            this,
            new String[]{ Manifest.permission.SEND_SMS },
            SMS_PERMISSION_REQUEST_CODE
        );
    }

    // NEW: Handle the user's response to the permission request
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            // Check if permission was granted
            if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // Permission granted: initialize the database and proceed to login
                DataRepository.getInstance(getApplicationContext());  // NEW: initialize Room database
                startActivity(new Intent(this, LoginActivity.class)); // NEW: go to login screen
                finish();                                            // NEW: close PermissionActivity

            } else {
                // Permission denied: inform the user and stay on this screen
                Toast.makeText(
                    this,
                    "I need SMS permission to import your reminders.",
                    Toast.LENGTH_LONG
                ).show();
            }
        }
    }
}

/*
Enhancements Explanation:

Imports for Intent, PackageManager, Toast, and NonNull.

onRequestPermissionsResult override to handle grant or denial.

Initialization of the Room-backed DataRepository when permission is granted.

Navigation to LoginActivity only after SMS permission is approved.

User feedback via a Toast if permission is denied.
 */