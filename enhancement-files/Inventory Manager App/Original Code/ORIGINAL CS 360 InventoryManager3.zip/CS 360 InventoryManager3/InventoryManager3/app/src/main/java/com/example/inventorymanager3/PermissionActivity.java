package com.example.inventorymanager;

import android.Manifest;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class PermissionActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_REQUEST_CODE);
    }
}

/*
  In lines 16 - 19, I’m asking Android to let my app send and read text messages. 
  On the app, a box pops up that says, ‘Allow Inventory Manager to use SMS?’ 
  If the user taps Allow, the app can send out reminders. 
  Later, I’ll add code to watch for their answer, so if they tap Deny, the app will show a message like 
  ‘I need SMS permission to work properly.’ That way, it won’t crash or leave the user guessing why it didn’t work


Code to add:


 startActivity(new Intent(this, LoginActivity.class))

Toast.makeText(this,
                "I need SMS permission to import your reminders.",
                Toast.LENGTH_LONG
            ).show();



 */