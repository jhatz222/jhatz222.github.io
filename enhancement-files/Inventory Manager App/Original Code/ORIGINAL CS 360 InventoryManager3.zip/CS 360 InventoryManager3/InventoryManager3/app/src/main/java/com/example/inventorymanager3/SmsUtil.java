package com.example.inventorymanager;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public class SmsUtil {
    public static PendingIntent getPendingIntent(Context context, Intent intent, int requestCode) {
        return PendingIntent.getActivity(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }
}

/*
  Lines 8 - 15 makes a PendingIntent, which is like a ‘reminder link’ that tells Android, 
 ‘When a text arrives, open this part of my app.’ 
 Right now it just opens the app screen, but I’ll add a step here later to read the actual text message and 
 turn it into an item in my to-do list. 
 That means as soon as a reminder text comes in, it will automatically show up in the app without 
 me having to type it in by hand


 Code to add:

 public static InventoryItem parseSms(String rawMessage) {
    String[] parts = rawMessage.split(";");
    String namePart = parts[0].split(":", 2)[1].trim();
    String datePart = parts[1].split(":", 2)[1].trim();
    Date dueDate = parseDate(datePart); // you’ll implement parseDate()
    return new InventoryItem(namePart, dueDate);
}

This reads a text string, pulls out the task name and due date, and returns the app’s InventoryItem


 */