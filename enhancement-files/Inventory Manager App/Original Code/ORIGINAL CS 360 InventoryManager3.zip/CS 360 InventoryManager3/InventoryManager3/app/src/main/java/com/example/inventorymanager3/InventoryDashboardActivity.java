package com.example.inventorymanager;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryDashboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_dashboard);
    }
}

/*
Code Enhancements: Create a new DataRepository class and the code below will be added:


DataRepository repo = new DataRepository(loadRawItems());
    List<InventoryItem> allItems = repo.getAllItems();
    RecyclerView rv = findViewById(R.id.recyclerview);
    rv.setAdapter(new InventoryAdapter(allItems));


*/

//Outcome: This will separate UI from data, keep things organized, and make future searches a lot faster