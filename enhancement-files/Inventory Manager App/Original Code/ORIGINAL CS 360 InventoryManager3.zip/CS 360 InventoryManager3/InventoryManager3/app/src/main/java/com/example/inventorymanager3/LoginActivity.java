package com.example.inventorymanager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, InventoryDashboardActivity.class);
                startActivity(intent);
            }
        });
    }
}

/*
Lines 15 - 22 is my login screen code. It jumps straight to the dashboard. 
Later, I’ll enhance it to check that data is loaded or that permissions are granted, so before startActivity, 
i’ll call something like repo.initialize() or checkDataReady() and show an error or loading spinner if needed. 
That adds a professional-quality check.



Code to be added:

if (!DataRepository.isInitialized()) {
            Toast.makeText(LoginActivity.this,
                "Hang on—loading your items now!",
                Toast.LENGTH_SHORT
            ).show();
            return;
        }


 */