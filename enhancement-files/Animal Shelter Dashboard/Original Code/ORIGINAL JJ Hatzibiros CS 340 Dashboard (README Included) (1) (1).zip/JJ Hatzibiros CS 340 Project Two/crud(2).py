# crud.py

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    def __init__(self, username, password, host, port, db, collection):
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}')
        self.database = self.client[db]
        self.collection = self.database[collection]

    # Create method
    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)
            return result.acknowledged
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method
    def read(self, search):
        if search is not None:
            result = self.collection.find(search)
            return list(result)
        else:
            raise Exception("Nothing to search, because search parameter is empty")

    # Update method
    def update(self, query, update_values):
        if query is not None and update_values is not None:
            result = self.collection.update_one(query, {'$set': update_values})
            return result.acknowledged
        else:
            raise Exception("Query or update_values parameter is empty")

    # Delete method
    def delete(self, query):
        if query is not None:
            result = self.collection.delete_one(query)
            return result.acknowledged
        else:
            raise Exception("Query parameter is empty")
