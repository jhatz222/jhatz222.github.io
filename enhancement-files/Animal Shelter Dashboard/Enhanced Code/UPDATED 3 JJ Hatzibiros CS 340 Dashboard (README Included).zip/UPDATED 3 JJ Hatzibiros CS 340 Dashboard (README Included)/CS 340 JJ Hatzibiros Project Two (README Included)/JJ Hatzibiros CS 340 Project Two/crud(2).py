# crud(2).py

from pymongo import MongoClient
from bson.objectid import ObjectId
from flask_socketio import SocketIO

class AnimalShelter(object):
    """
    AnimalShelter handles CRUD operations on the 'animals' collection,
    plus a separate 'comments' collection.  It uses Flask-SocketIO to 
    broadcast two distinct channels:
      - 'new_data'    → for animal insert/update/delete events
      - 'new_comment' → for new comment events (opt-in by clients)
    """
    def __init__(self, username, password, host, port, db, collection, app=None):
        """
        Connect to MongoDB and set up SocketIO.  If you pass in your Flask
        app instance, SocketIO attaches to it; otherwise it creates its own.
        """
        # 1) Connect to the specified MongoDB database and collection
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}')
        self.database = self.client[db]
        # Primary collection (e.g. "animals" or whatever you named it)
        self.collection = self.database[collection]
        # Separate collection for comments
        self.comments_collection = self.database["comments"]

        # 2) Create a SocketIO instance (attach to Flask app if provided)
        self.socketio = SocketIO(app) if app else SocketIO()

    def create(self, data):
        """
        Insert a new animal record into MongoDB, then broadcast that record
        on the 'new_data' channel to *all* connected clients.
        """
        if data is None:
            raise Exception("Nothing to save, because data parameter is empty")

        result = self.collection.insert_one(data)
        # Broadcast the newly inserted animal record on 'new_data'
        self.socketio.send('new_data', data, broadcast=True)
        return result.acknowledged

    def read(self, search):
        """
        Find animal documents matching 'search' and return them as a list.
        (No broadcast here—just returns data to the caller.)
        """
        if search is None:
            raise Exception("Nothing to search, because search parameter is empty")

        result = self.collection.find(search)
        return list(result)

    def update(self, query, update_values):
        """
        Update a single animal document matching 'query' with the fields in
        'update_values'.  If successful, broadcast the updated data on 'new_data'.
        """
        if query is None or update_values is None:
            raise Exception("Query or update_values parameter is empty")

        result = self.collection.update_one(query, {'$set': update_values})
        if not result.acknowledged:
            raise Exception("No record found to update")

        # Broadcast the updated values on 'new_data'
        self.socketio.send('new_data', update_values, broadcast=True)
        return result.acknowledged

    def delete(self, query):
        """
        Delete one animal document matching 'query'.  If a document was removed,
        broadcast which record was deleted on 'new_data'.
        """
        if query is None:
            raise Exception("Query parameter is empty")

        result = self.collection.delete_one(query)
        if result.deleted_count == 0:
            raise Exception("No record found to delete")

        # Broadcast the deletion info on 'new_data'
        self.socketio.send('new_data', {'deleted': query}, broadcast=True)
        return result.acknowledged

    def create_comment(self, comment_data):
        """
        Insert a new comment into the 'comments' collection, then broadcast
        that comment on the 'new_comment' channel to *all* connected clients
        who have opted in.  Clients that did not subscribe will not receive it.
        """
        if comment_data is None:
            raise Exception("Empty comment is not allowed")

        result = self.comments_collection.insert_one(comment_data)
        # Broadcast the new comment on 'new_comment'
        self.socketio.send('new_comment', comment_data, broadcast=True)
        return result.acknowledged

